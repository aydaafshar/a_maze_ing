# A-Maze-ing

A maze generation and solving application built in Python.

## Running the Application

```bash
make install
make run
```

The interactive menu allows you to:
1. Generate new mazes with random seeds
2. Show/hide the solution path
3. Rotate wall colors
4. Quit

## Configuration

Edit `config.txt` to customize maze parameters:

```
WIDTH=15
HEIGHT=10
ENTRY=0,0
EXIT=7,7
OUTPUT_FILE=maze.txt
PERFECT=True
```

---

## Reusable Module: `mazegen`

The `mazegen` package is a standalone, pip-installable module for maze generation and solving.

### Installation

Build and install from source:

```bash
pip install build
python -m build
pip install dist/mazegen-1.0.0-py3-none-any.whl
```

Or install directly from the repository:

```bash
pip install .
```

### Quick Start

```python
from mazegen import MazeGenerator

# Create a maze with default parameters (20x15, seed=42, perfect maze)
mg = MazeGenerator()

# Create a maze with custom parameters
mg = MazeGenerator(width=30, height=20, seed=123, perfect=False)
```

### Custom Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `width` | int | 20 | Maze width in cells |
| `height` | int | 15 | Maze height in cells |
| `entry` | (int, int) | (0, 0) | Entry point coordinates (x, y) |
| `exit` | (int, int) | (width-1, height-1) | Exit point coordinates (x, y) |
| `seed` | int | 42 | Random seed for reproducible mazes |
| `perfect` | bool | True | True = no loops, False = ~10% random loops |

```python
mg = MazeGenerator(
    width=40,
    height=30,
    entry=(0, 0),
    exit=(39, 29),
    seed=99,
    perfect=False,
)
```

### Accessing the Maze Structure

The maze is a 2D grid of cells, accessed as `cells[y][x]`. Each cell has four boolean wall attributes (`True` = wall exists, `False` = open passage):

```python
mg = MazeGenerator(width=10, height=10)

# Access a specific cell's walls
cell = mg.cells[0][0]
print(cell.north, cell.east, cell.south, cell.west)

# Helper method for wall states
north, east, south, west = mg.cell_walls(5, 3)

# Maze properties
print(mg.width, mg.height)
print(mg.entry, mg.exit)
print(mg.seed)
```

### Accessing the Solution

```python
mg = MazeGenerator(width=10, height=10, seed=42)

# Get solution path as list of (x, y) coordinates
path = mg.solution
print(f"Solution has {len(path)} steps")
print(f"Start: {path[0]}, End: {path[-1]}")

# Regenerate with a new seed and get a new solution
mg.regenerate(seed=100)
new_path = mg.solution
```

### Building the Package

```bash
pip install build
python -m build
```

This produces both `.tar.gz` and `.whl` files in the `dist/` directory:
- `dist/mazegen-1.0.0.tar.gz`
- `dist/mazegen-1.0.0-py3-none-any.whl`
